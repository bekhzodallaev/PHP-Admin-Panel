
-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(1, 'smartphone 4gb ram', '100', 'product-1.jpg'),
(2, 'premium watch white coloured', '100', 'product-2.jpg'),
(3, 'nikon hd camera black', '50', 'product-3.jpg'),
(4, 'smart speaker black', '150', 'product-4.jpg'),
(5, 'premium wired headset', '50', 'product-5.jpg'),
(6, 'smart LED flat TV', '400', 'product-6.jpg');
